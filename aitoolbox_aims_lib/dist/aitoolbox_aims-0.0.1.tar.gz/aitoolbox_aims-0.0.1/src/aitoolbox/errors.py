class ServiceError(Exception):
    pass